import Config

config :logger,
  backends: [Centry.Backend]

config :logger, Centry.Backend,
  directory: System.tmp_dir(),
  log_extension: "log"
