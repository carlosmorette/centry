defmodule CentryTest do
  use ExUnit.Case
  doctest Centry

  test "greets the world" do
    assert Centry.hello() == :world
  end
end
