defmodule Centry do
  @moduledoc """
  Documentation for `Centry`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Centry.hello()
      :world

  """
  def hello do
    :world
  end
end
