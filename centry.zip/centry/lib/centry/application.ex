defmodule Centry.Application do
  # See https://hexdocs.pm/elixir/Application.html
  # for more information on OTP Applications
  @moduledoc false

  use Application

  @impl true
  def start(_type, _args) do
    children = [
      #Centry.Backend
      # Starts a worker by calling: Centry.Worker.start_link(arg)
      # {Centry.Worker, arg}
    ]

    # See https://hexdocs.pm/elixir/Supervisor.html
    # for other strategies and supported options
    opts = [strategy: :one_for_one, name: Centry.Supervisor]
    Supervisor.start_link(children, opts)
  end
end
