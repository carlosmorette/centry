defmodule Centry.Backend do

  @config Application.compile_env(:logger, __MODULE__)

  defp dir, do: @config[:directory]
  defp log_extension, do: @config[:log_extension]

  def init(state), do: {:ok, state}

  def handle_event({level, _gl, {Logger, message, timestamp, _extra_timestamp}}, state) do
    {{year, month, day}, {hour, minute, second, _milli}} = timestamp
    moment = {year, month, day, hour, minute, second}
    Task.start(fn -> store(level, message, moment) end)
    {:ok, state}
  end

  def store(level, message, moment) do
    {year, month, day, hour, minute, second} = moment
    filename = build_filename(year, month, day)
    path = Path.join(dir(), filename)
    message_complement = "[#{level}]: #{hour}:#{minute}:#{second} -> #{message}" <> "\n"
    File.write(path, message_complement, [:append])
  end

  defp build_filename(year, month, day), do: "#{year}_#{month}_#{day}.#{log_extension()}"
end
